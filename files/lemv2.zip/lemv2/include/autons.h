#pragma once
#include "main.h"

extern void turnRobot(double angle);
extern void rollerAuton(void);
extern void awpAuton(void);
extern void skillsAuton(void);
extern void experimentalAuton(void);
