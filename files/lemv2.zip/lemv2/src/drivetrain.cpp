#include "lemlib/chassis/chassis.hpp"
#include "main.h"
#include "pros/misc.h"
#include "pros/motors.h"
#include <cmath>

int leftTarget; int rightTarget;
int leftPower; int rightPower;
int leftPrev; int rightPrev;

bool driveInvert = false;
bool brakeHold = false;
std::string driveCurrent = "FW";
std::string brakeCurrent = "NB";

Motor leftA(1, E_MOTOR_GEARSET_06, false);
Motor leftB(2, E_MOTOR_GEARSET_06, false);
Motor leftC(3, E_MOTOR_GEARSET_06, false);
Motor rightA(4, E_MOTOR_GEARSET_06, true);
Motor rightB(5, E_MOTOR_GEARSET_06, true);
Motor rightC(6, E_MOTOR_GEARSET_06, true);
MotorGroup leftDrive({leftA, leftB, leftC});
MotorGroup rightDrive({rightA, rightB, rightC});
MotorGroup drive({leftA, leftB, leftC, rightA, rightB, rightC});

lemlib::Drivetrain_t drivetrain {
	&leftDrive,
	&rightDrive,
	10.1575,
	4.125,
	360
};

ADIEncoder leftEnc('C', 'D', true);
ADIEncoder rightEnc('E', 'F', false);
ADIEncoder backEnc('G', 'H', false);

lemlib::TrackingWheel leftTrack(&leftEnc, 2.75, -5);
lemlib::TrackingWheel rightTrack(&rightEnc, 2.75, 5);
lemlib::TrackingWheel backTrack(&backEnc, 2.75, 7.08661);

lemlib::OdomSensors_t sensors {
	&leftTrack,
	&rightTrack,
	&backTrack,
	nullptr,
	nullptr
};

// forward/backward PID
lemlib::ChassisController_t lateralController {
    10, // kP
    30, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500, // largeErrorTimeout
    5 // slew rate
};
 
// turning PID
lemlib::ChassisController_t angularController {
    2, // kP
    10, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500, // largeErrorTimeout
    5 // slew rate
};

// create the chassis
lemlib::Chassis chassis(drivetrain, lateralController, angularController, sensors);

float gradient = 0.5;
float scaledInput = 127;
float scaledOutput = 12000;

void chassisControl (void) {
	leftTarget = master.get_analog(ANALOG_LEFT_Y);
	rightTarget = master.get_analog(ANALOG_RIGHT_Y);
	leftPower = (scaledOutput * tan((leftTarget / scaledInput) * atan(gradient))) / gradient;
	rightPower = (scaledOutput * tan((rightTarget / scaledInput) * atan(gradient))) / gradient;
	
	leftA.move_voltage(leftPower);
	leftB.move_voltage(leftPower);
	leftC.move_voltage(leftPower);
	rightA.move_voltage(rightPower);
	rightB.move_voltage(rightPower);
	rightC.move_voltage(rightPower);
	
//	leftA.move_voltage((leftPower + leftPrev) / 2);
//	leftB.move_voltage((leftPower + leftPrev) / 2);
//	leftC.move_voltage((leftPower + leftPrev) / 2);
//	rightA.move_voltage((rightPower + rightPrev) / 2);
//	rightB.move_voltage((rightPower + rightPrev) / 2);
//	rightC.move_voltage((rightPower + rightPrev) / 2);	
	
	leftPrev = leftPower;
	rightPrev = rightPower;}