#pragma once
#include "main.h"

extern double desiredLatValue;
extern double desiredTurnValue;

extern double lP;
extern double lI;
extern double lD;
extern double tP;
extern double tI;
extern double tD;

extern double latError;
extern double latPrevError;
extern double latDerivative;
extern double latTotalError;
 
extern double turnError;
extern double turnPrevError;
extern double turnDerivative;
extern double turnTotalError;

extern bool resPIDEnc;
extern bool enableDrivePID;

extern int drivePID();