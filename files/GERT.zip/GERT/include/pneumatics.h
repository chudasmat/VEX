#pragma once
#include "main.h"

extern pros::ADIDigitalOut disc1;
extern pros::ADIDigitalOut disc3;
extern pros::ADIDigitalOut stringS;

extern void pneumatics (void);