#pragma once
#include "main.h"

extern bool intakeSpinning;
extern pros::Motor intake;
extern void intakeControl (void);