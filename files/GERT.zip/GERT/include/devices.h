#pragma once
#include "main.h"
using namespace pros;

extern okapi::Controller master1;
extern Controller master;

extern Motor leftA;
extern Motor leftB;
extern Motor rightA;
extern Motor rightB;
extern MotorGroup drive;
extern std::shared_ptr<okapi::OdomChassisController> chassis;

extern Motor intake;
extern Motor roller;

extern sylib::SpeedControllerInfo flyController;
extern sylib::Motor fly;

extern ADIDigitalOut disc1;
extern ADIDigitalOut disc3;
extern ADIDigitalOut stringS;

extern Optical optical;

extern sylib::Addrled ledStrip1;
extern sylib::Addrled ledStrip2;
