#pragma once
#include "main.h"

extern bool tbhEnable;
extern bool resFlyEnc;
extern double tbhError;
extern double tbhGoal;
extern double tbhPrevError;
extern double tbhOutput;
extern double tbh;
extern double tbhGain;
extern int tbhCntrl();