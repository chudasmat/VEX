#pragma once
#include "main.h"

extern bool rollerSpinning;
extern pros::Motor roller;
extern pros::Optical optical;
extern void rollerControl(void);