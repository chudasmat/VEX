#pragma once
#include "main.h"
extern void drivercontrol(void);
extern bool lightDirec;
extern bool intakeSpinning;
extern bool rollerSpinning;
extern bool flySpinning;
extern bool driveInvert;
extern bool brakeHol;
extern std::string driveCurrent;
extern std::string brakeCurrent;