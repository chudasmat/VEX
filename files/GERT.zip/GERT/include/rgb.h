#pragma once
#include "main.h"
extern bool lightDirec;
extern sylib::Addrled ledStrip1;
extern sylib::Addrled ledStrip2;

extern void rgb (void);