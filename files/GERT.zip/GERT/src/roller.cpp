#include "display/lv_objx/lv_roller.h"
#include "main.h"
#include "roller.h"

bool rollerSpinning = false;
Motor roller(12, MOTOR_GEAR_100);
Optical optical(11);

void rollerControl (void) {
    while (true) {
		if (master.get_digital_new_press(DIGITAL_Y)){
			if (rollerSpinning) {roller.move_velocity(0);}
			else {roller.move_voltage(12);}
			rollerSpinning = !rollerSpinning;}
		if (master.get_digital_new_press(DIGITAL_B)) {rollerSpinning = true; roller.move_voltage(-12);}  
    delay(10);     
    }
}