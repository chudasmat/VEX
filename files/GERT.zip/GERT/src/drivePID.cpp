#include "main.h"

// Autonomous Settings //
double desiredLatValue = 200;		// Straight-Line Value
double desiredTurnValue = 0;  		// Spin Value

// PID Values //
double lP = 0.0;        			//////////////////////
double lI = 0.0;        			//                  //
double lD = 0.0;        			//      Requires    //
double tP = 0.0;    				//      Tuning      //
double tI = 0.0;    				//                  //
double tD = 0.0;    				//////////////////////

double latError;					// sensorValue - desiredValue (Position)
double latPrevError = 0;			// Position 10ms ago
double latDerivative;				// pidError - pidPrevError (Speed)
double latTotalError = 0;			// totalError = totalError + pidError

double turnError;					// sensorValue - desiredValue (Position)
double turnPrevError = 0;			// Position 10ms ago
double turnDerivative;				// pidError - pidPrevError (Speed)
double turnTotalError = 0;			// totalError = totalError + pidError

bool resPIDEnc = false;
bool enableDrivePID = true;

int drivePID() {
	while (enableDrivePID) {
		if (resPIDEnc) {
		resPIDEnc = false;
		leftA.tare_position(); leftB.tare_position(); 
		rightA.tare_position(); rightB.tare_position();}

		double leftApos = leftA.get_position();
		double leftBpos = leftB.get_position();
		double rightApos = rightA.get_position();
		double rightBpos = rightB.get_position();

		double avgLatPos = (leftApos + leftBpos + rightApos + rightBpos) / 4;
		latError = avgLatPos - desiredLatValue;
		latDerivative = latError - latPrevError;
		latTotalError += latError;
		double latPower = (latError * lP) + (latDerivative * lD) + (latTotalError * lI);

		double avgTurnPos = (leftApos - leftBpos - rightApos - rightBpos) / 4;
		turnError = avgTurnPos - desiredTurnValue;
		turnDerivative = turnError - turnPrevError;
		turnTotalError += turnError;
		double turnPower = (turnError * tP) + (turnDerivative * tD) + (turnTotalError * tI);

		leftA.move_voltage(latPower + turnPower);
		leftB.move_voltage(latPower + turnPower);
		rightA.move_voltage(latPower - turnPower);
		rightB.move_voltage(latPower - turnPower);

		latPrevError = latError;
		turnPrevError = turnError;

		Task::delay(10);
	} return 1;}