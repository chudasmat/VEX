#include "main.h"

Controller master(CONTROLLER_MASTER);
okapi::Controller okapiController;