#include "main.h"
#include <memory>

okapi::Controller master1;
Controller master(CONTROLLER_MASTER);

Motor rightA(3, MOTOR_GEAR_200, false, MOTOR_ENCODER_DEGREES);
Motor rightB(4, MOTOR_GEAR_200, false, MOTOR_ENCODER_DEGREES);
Motor leftA(1, MOTOR_GEAR_200, true, MOTOR_ENCODER_DEGREES);
Motor leftB(2, MOTOR_GEAR_200, true, MOTOR_ENCODER_DEGREES);
MotorGroup drive({leftA, leftB, rightA, rightB});

std::shared_ptr<okapi::OdomChassisController> chassis = okapi::ChassisControllerBuilder()
.withMotors({1, 2}, {3, 4})
// .withGains({0.001, 0, 0.0001},
//          {0.001, 0, 0.0001},
//          {0.001, 0, 0.0001})
.withSensors(okapi::ADIEncoder{'C', 'D'}, 
 		okapi::ADIEncoder{'E', 'F', true}, 
 		okapi::ADIEncoder{'G', 'H'})
.withDimensions({okapi::AbstractMotor::gearset::green, (60.0/84.0)}, {{4.125_in, 15_in}, okapi::imev5GreenTPR})
.withOdometry({{2.75_in, 9.8_in, 6.5_in, 2.75_in}, okapi::quadEncoderTPR}, okapi::StateMode::FRAME_TRANSFORMATION)  // Add ADI Encoders after Gains and add tracking wheel size with track width
.buildOdometry();

Motor intake(20, MOTOR_GEAR_200, true);
Motor roller(12, MOTOR_GEAR_100);

sylib::SpeedControllerInfo flyController (
        [](double rpm){return 5;}, // kV function
        0, // kP
        0, // kI
        0, // kD
        0.245 // kH
);

sylib::Motor fly(15, 3600, false, flyController);

ADIDigitalOut disc1(1);
ADIDigitalOut disc3(2);
ADIDigitalOut stringS({{13, 3}});

Optical optical(11);

sylib::Addrled ledStrip1(13, 1, 25);
sylib::Addrled ledStrip2(13, 2, 25);