#include "main.h"

bool tbhEnable = true;
bool resFlyEnc = false;
double tbhError = 0;
double tbhGoal = 3400;
double tbhPrevError = 0;
double tbhOutput = 0;
double tbh = 0;
double tbhGain = 0.23;

int tbhCntrl() {
	while (flySpinning) {
		double currVel = fly.get_velocity();
		tbhError = tbhGoal - currVel;
		if (tbhOutput + (tbhError * tbhGain) < (tbhGoal + 35)) {
			tbhOutput += tbhError * tbhGain;}
		if (std::signbit(tbhError) != std::signbit(tbhPrevError)) {
			tbhOutput = (tbhOutput + tbh) / 2;
			tbh = tbhOutput;}
		delay(10);}
	return 1;}