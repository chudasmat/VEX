#include "main.h"
#include "okapi/api/util/mathUtil.hpp"
#include "okapi/impl/device/rotarysensor/adiEncoder.hpp"
#include "pros/adi.hpp"
#include "sylib/sylib.hpp"
#include "gif-pros/gifclass.hpp"
#include "okapi/api.hpp"
#include <cmath>
#include <memory>
#include <string>
using namespace okapi::literals;

Controller master(E_CONTROLLER_MASTER);
auto ledStrip1 = sylib::Addrled(13, 1, 25);
auto ledStrip2 = sylib::Addrled(13, 2, 25);
Motor leftA(1, MOTOR_GEAR_200, false, MOTOR_ENCODER_DEGREES);
Motor leftB(2, MOTOR_GEAR_200, false, MOTOR_ENCODER_DEGREES);
Motor rightA(3, MOTOR_GEAR_200, true, MOTOR_ENCODER_DEGREES);
Motor rightB(4, MOTOR_GEAR_200, true, MOTOR_ENCODER_DEGREES);
MotorGroup drive({leftA, leftB, rightA, rightB});
sylib::Motor flyA(15, 3600, false);
sylib::Motor flyB(14, 3600, true);
Motor intake(20, MOTOR_GEAR_200, true);
Motor roller(12, MOTOR_GEAR_100);
Optical optical(11);
ADIDigitalOut indexer(2);
ADIDigitalOut stringS(1);

std::shared_ptr<okapi::OdomChassisController> chassis = okapi::ChassisControllerBuilder()
.withMotors({1, 2}, {-3, -4})
.withGains({0.001, 0, 0.0001},
        {0.001, 0, 0.0001},
        {0.001, 0, 0.0001})
.withSensors(okapi::ADIEncoder{'C', 'D'}, 
			okapi::ADIEncoder{'E', 'F', true}, 
			okapi::ADIEncoder{'G', 'H'})
.withDimensions({okapi::AbstractMotor::gearset::green, (60.0/84.0)}, {{4.125_in, 15_in}, okapi::imev5GreenTPR})
.withOdometry({{2.75_in, 9.8_in, 6.5_in, 2.75_in}, okapi::quadEncoderTPR}, okapi::StateMode::FRAME_TRANSFORMATION)  // Add ADI Encoders after Gains and add tracking wheel size with track width
.buildOdometry();

bool lightDirec = true;
bool intakeSpinning = false;
bool rollerSpinning = false;
bool flySpinning = false;
bool driveInvert = false;
bool brakeHold = false;
std::string driveCurrent = "FW";
std::string brakeCurrent = "BR";

bool tbhEnable = true;
bool resFlyEnc = false;
double tbhError = 0;
double tbhGoal = 560;
double tbhPrevError = 0;
double tbhOutput = 0;
double tbh = 0;
double tbhGain = 0.5;

int tbhCntrl() {
	while (tbhEnable) {
		double currVel = (flyA.get_velocity() + flyB.get_velocity()) / 2;
		tbhError = tbhGoal - currVel;
		if (tbhOutput + (tbhError * tbhGain) < (tbhGoal + 35)) {
			tbhOutput += tbhError * tbhGain;}
		if (std::signbit(tbhError) != std::signbit(tbhPrevError)) {
			tbhOutput = (tbhOutput + tbh) / 2;
			tbh = tbhOutput;}
		delay(10);}
	return 1;}

// Autonomous Settings //
double desiredLatValue = 200;		// Straight-Line Value
double desiredTurnValue = 0;  		// Spin Value

// PID Values //
double lP = 0.0;        			//////////////////////
double lI = 0.0;        			//                  //
double lD = 0.0;        			//      Requires    //
double tP = 0.0;    				//      Tuning      //
double tI = 0.0;    				//                  //
double tD = 0.0;    				//////////////////////

double latError;					// sensorValue - desiredValue (Position)
double latPrevError = 0;			// Position 10ms ago
double latDerivative;				// pidError - pidPrevError (Speed)
double latTotalError = 0;			// totalError = totalError + pidError

double turnError;					// sensorValue - desiredValue (Position)
double turnPrevError = 0;			// Position 10ms ago
double turnDerivative;				// pidError - pidPrevError (Speed)
double turnTotalError = 0;			// totalError = totalError + pidError

bool resPIDEnc = false;
bool enableDrivePID = true;

int drivePID() {
	while (enableDrivePID) {
		if (resPIDEnc) {
		resPIDEnc = false;
		leftA.tare_position(); leftB.tare_position(); 
		rightA.tare_position(); rightB.tare_position();}

		double leftApos = leftA.get_position();
		double leftBpos = leftB.get_position();
		double rightApos = rightA.get_position();
		double rightBpos = rightB.get_position();

		double avgLatPos = (leftApos + leftBpos + rightApos + rightBpos) / 4;
		latError = avgLatPos - desiredLatValue;
		latDerivative = latError - latPrevError;
		latTotalError += latError;
		double latPower = (latError * lP) + (latDerivative * lD) + (latTotalError * lI);

		double avgTurnPos = (leftApos - leftBpos - rightApos - rightBpos) / 4;
		turnError = avgTurnPos - desiredTurnValue;
		turnDerivative = turnError - turnPrevError;
		turnTotalError += turnError;
		double turnPower = (turnError * tP) + (turnDerivative * tD) + (turnTotalError * tI);

		leftA.move_voltage(latPower + turnPower);
		leftB.move_voltage(latPower + turnPower);
		rightA.move_voltage(latPower - turnPower);
		rightB.move_voltage(latPower - turnPower);

		latPrevError = latError;
		turnPrevError = turnError;

		Task::delay(10);
	} return 1;}

void initialize() {
	sylib::initialize();
	enableDrivePID = true;
	ledStrip1.gradient(0xFF0000, 0xFF0005, 0, 0, false, true);
	ledStrip1.cycle(*ledStrip1, 4, true);
	ledStrip2.gradient(0xFF0000, 0xFF0005, 0, 0, false, true);
	ledStrip2.cycle(*ledStrip1, 4, true);
	
	Task TBH_(tbhCntrl);
	Task PID_(drivePID);
	static Gif gif("/usd/slideshow.gif", lv_scr_act());

//	Task sylibTBH(sylibCntrl);
}

void disabled() {}
void competition_initialize() {}

void autonomous() {
	chassis->setState({0_in, 0_in, 0_deg});
	chassis->driveToPoint({1_in, 1_in});
	chassis->moveDistance(-0.75_m);
	roller.move_velocity(-100);
	delay(750);
	roller.move(0);
	chassis->moveDistance(1_m);
	chassis->turnAngle(90_deg);
	chassis->moveDistance(1_m);
}

void opcontrol() {
	enableDrivePID = false;
	while (true) {	
		if (!driveInvert) {
			leftA.move(master.get_analog(ANALOG_LEFT_Y));
			leftB.move(master.get_analog(ANALOG_LEFT_Y));
			rightA.move(master.get_analog(ANALOG_RIGHT_Y));
			rightB.move(master.get_analog(ANALOG_RIGHT_Y));}
		else {
			leftA.move(-(master.get_analog(ANALOG_RIGHT_Y)));
			leftB.move(-(master.get_analog(ANALOG_RIGHT_Y)));
			rightA.move(-(master.get_analog(ANALOG_LEFT_Y)));
			rightB.move(-(master.get_analog(ANALOG_LEFT_Y)));}

		if (master.get_digital_new_press(DIGITAL_L1)) {
			driveInvert = !driveInvert;
			lightDirec = !lightDirec;
			ledStrip1.cycle(*ledStrip1, 4, 0, lightDirec);
			ledStrip2.cycle(*ledStrip1, 4, 0, lightDirec);
			if (driveInvert) {driveCurrent = "IT";} else {driveCurrent = "FW";}}

		if (master.get_digital_new_press(DIGITAL_L2)){
			if (flySpinning) {flyA.stop(); flyB.stop();}
			else {flyA.set_velocity(tbhOutput); flyB.set_velocity(tbhOutput);}
			flySpinning = !flySpinning;}

		if (master.get_digital_new_press(DIGITAL_RIGHT)){
			if (intakeSpinning) {intake.move_velocity(0);}
			else {intake.move_velocity(200);}
			intakeSpinning = !intakeSpinning;}
		if (master.get_digital_new_press(DIGITAL_DOWN)) {intakeSpinning = true; intake.move(-12);}
		
		if (master.get_digital_new_press(DIGITAL_Y)){
			if (rollerSpinning) {roller.move_velocity(0);}
			else {roller.move_velocity(100);}
			rollerSpinning = !rollerSpinning;}
		if (master.get_digital_new_press(DIGITAL_B)) {rollerSpinning = true; roller.move(-12);}
		
		if (master.get_digital_new_press(DIGITAL_Y)){
			if (brakeHold) {drive.set_brake_modes(MOTOR_BRAKE_COAST);}
			else {drive.set_brake_modes(MOTOR_BRAKE_HOLD);}
			brakeHold = !brakeHold;
			if (brakeHold) {brakeCurrent = "BR";} else {brakeCurrent = "NB";}}

		if (master.get_digital(DIGITAL_L2)) {indexer.set_value(true); delay(200);}
		else {indexer.set_value(false);}

		if (master.get_digital(DIGITAL_X)) {stringS.set_value(true); delay(200); stringS.set_value(false);}

		pros::delay(10);}}
