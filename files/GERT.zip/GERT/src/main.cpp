#include "main.h"
#include "sylib/sylib.hpp"
#include <cmath>
#include <memory>
#include <string>

Controller master(pros::E_CONTROLLER_MASTER);
auto ledStrip = sylib::Addrled(22, 2, 25);
Motor leftA(1, E_MOTOR_GEAR_200, false, E_MOTOR_ENCODER_DEGREES);
Motor leftB(2, E_MOTOR_GEAR_200, false, E_MOTOR_ENCODER_DEGREES);
Motor rightA(3, E_MOTOR_GEAR_200, true, E_MOTOR_ENCODER_DEGREES);
Motor rightB(4, E_MOTOR_GEAR_200, true, E_MOTOR_ENCODER_DEGREES);
Motor_Group drive({leftA, leftB, rightA, rightB});
sylib::Motor flyA(15, 600, false);
sylib::Motor flyB(14, 600, true);
Motor intake(20, E_MOTOR_GEAR_200, true);
Motor roller(12, E_MOTOR_GEAR_100);
Optical optical(11);
ADIDigitalOut indexer(4);
ADIDigitalOut string(1);

bool intakeSpinning = false;
bool rollerSpinning = false;
bool flySpinning = false;
bool driveInvert = false;
bool brakeHold = false;
std::string driveCurrent = "FW";
std::string brakeCurrent = "BR";

double flySpeed = 0.0;

bool tbhEnable = true;
bool resFlyEnc = false;
double tbhError = 0;
double tbhGoal = 560;
double tbhPrevError = 0;
double tbhOutput = 0;
double tbh = 0;
double tbhGain = 0.5;

std::shared_ptr<double> tbhErr;
sylib::TakeBackHalfController tbhSylib(
	0.7,
	tbhErr
);

void tbhCntrl(void) {
	while (tbhEnable) {
		double currVel = (flyA.get_velocity() + flyB.get_velocity()) / 2;
		tbhError = tbhGoal - currVel;
		if (tbhOutput + (tbhError * tbhGain) < (tbhGoal + 35)) {
			tbhOutput += tbhError * tbhGain;}
		if (std::signbit(tbhError) != std::signbit(tbhPrevError)) {
			tbhOutput = (tbhOutput + tbh) / 2;
			tbh = tbhOutput;}
		delay(10);
	}
}

void sylibCntrl (void) {
	flySpeed = tbhSylib.update();
	sylib::delay(10);
}

void intakeToggle(void) {
	if (intakeSpinning) {
		intake.move(0);}
	else {
		intake.move(12);}
	intakeSpinning = !intakeSpinning;}

void rollerToggle(void) {
	if (rollerSpinning) {
		roller.move(0);}
	else {
		roller.move(12);}
	rollerSpinning = !rollerSpinning;}

void flyToggle(void) {
	if (flySpinning) {
		flyA.stop();
		flyB.stop();}
	else {
		flyA.set_velocity(flySpeed);
		flyA.set_velocity(flySpeed);}
	flySpinning = !flySpinning;}

void driveToggle(void) {
	if (!driveInvert) {
		driveInvert = true;
		driveCurrent = "IT";}
	else if (driveInvert) {
		driveInvert = false;
		driveCurrent = "FW"}}

void brakeToggle(void) {
	if (!brakeHold) {
		brakeHold = true;
		brakeCurrent = "BR";
		drive.set_brake_modes(E_MOTOR_BRAKE_HOLD);}
	else if (brakeHold) {
		brakeHold = false;
		brakeCurrent = "NB";
		drive.set_brake_modes(E_MOTOR_BRAKE_COAST);}}

void initialize() {
	sylib::initialize();
	pros::lcd::initialize();
	ledStrip.gradient(0xFF0000, 0xFF0005, 0, 0, false, true);
	ledStrip.cycle(*ledStrip, 10);
	Task sylibTBH(sylibCntrl);
//	Task TBH_(tbhCntrl);
}

void disabled() {}
void competition_initialize() {}

void autonomous() {
	flyA.set_voltage(12);
	flyB.set_voltage(12);
	drive.move_absolute(-1000, 70);
	roller.move(-12);
	delay(750);
	roller.move(0);
	drive.move_absolute(500, 70);
}

void opcontrol() {
	while (true) {
		
		if (!driveInvert) {
			leftA.move_velocity((master.get_analog(ANALOG_LEFT_Y)) / 1.57480315));
			leftB.move_velocity((master.get_analog(ANALOG_LEFT_Y)) / 1.57480315);
			rightA.move_velocity((master.get_analog(ANALOG_RIGHT_Y)) / 1.57480315);
			rightB.move_velocity((master.get_analog(ANALOG_RIGHT_Y)) / 1.57480315);}
		else {
			leftA.move_velocity(-(master.get_analog(ANALOG_RIGHT_Y)) / 1.57480315);
			leftB.move_velocity(-(master.get_analog(ANALOG_RIGHT_Y)) / 1.57480315);
			rightA.move_velocity(-(master.get_analog(ANALOG_LEFT_Y)) / 1.57480315);
			rightB.move_velocity(-(master.get_analog(ANALOG_LEFT_Y)) / 1.57480315);}

		if (master.get_digital_new_press(DIGITAL_DOWN) == 1) {
			intakeSpinning = true;
			intake.move(-12);}
		if (master.get_digital_new_press(DIGITAL_B) == 1) {
			rollerSpinning = true;
			roller.move(-12);}
		if (master.get_digital_new_press(DIGITAL_A) == 1) {
			string.set_value(true);
			delay(500);
			string.set_value(false);}
		if (master.get_digital_new_press(DIGITAL_L2) == 1) {
			flyToggle();}
		if (master.get_digital_new_press(DIGITAL_L1) == 1) {
			driveToggle();}
		if (master.get_digital_new_press(DIGITAL_R1) == 1) {
			brakeToggle();}
		if (master.get_digital_new_press(DIGITAL_RIGHT) == 1) {
			intakeToggle();}
		if (master.get_digital_new_press(DIGITAL_Y) == 1) {
			rollerToggle();}
		if (master.get_digital_new_press(DIGITAL_L2) == 1) {
			indexer.set_value(true);
			indexer.set_value(false);}
		pros::delay(10);}
}
