#include "main.h"

void initialize() {
	sylib::initialize();
	ledStrip1.gradient(0xFF0000, 0xFF0005, 0, 0, false, true);
	ledStrip1.cycle(*ledStrip1, 4, true);
	ledStrip2.gradient(0xFF0000, 0xFF0005, 0, 0, false, true);
	ledStrip2.cycle(*ledStrip1, 4, true);
	
	Task TBH_(tbhCntrl);
	Task PID_(drivePID);
	static Gif gif("/usd/slideshow.gif", lv_scr_act());
}

void disabled() {}
void competition_initialize() {}

void autonomous() {
	chassisDrive->setState({0_in, 0_in, 0_deg});
	//  chassis->moveDistance(-12_in);
	//  chassis->moveDistance(12_in);
	//  chassis->turnAngle(45_deg);
	//  chassis->moveDistance(8_ft);
	//  chassis->waitUntilSettled();
	chassisDrive->driveToPoint({12_in, 12_in});
	chassisDrive->moveDistance(-16.97_in);
	chassisDrive->driveToPoint({0_in, 0_in}  );
	chassisDrive->turnToAngle(0_deg);
}

void opcontrol() {
	drivercontrol();}