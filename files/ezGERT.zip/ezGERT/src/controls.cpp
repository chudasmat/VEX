#include "main.h"

bool lightDirec = true;
bool intakeSpinning = false;
bool rollerSpinning = false;
bool flySpinning = false;
bool driveInvert = false;
bool brakeHold = false;
std::string driveCurrent = "FW";
std::string brakeCurrent = "BR";

void drivercontrol(void) {
	while (true) {
		if (!driveInvert) {
			leftA.move(master.get_analog(ANALOG_LEFT_Y));
			leftB.move(master.get_analog(ANALOG_LEFT_Y));
			rightA.move(master.get_analog(ANALOG_RIGHT_Y));
			rightB.move(master.get_analog(ANALOG_RIGHT_Y));}
		else {
			leftA.move(-(master.get_analog(ANALOG_RIGHT_Y)));
			leftB.move(-(master.get_analog(ANALOG_RIGHT_Y)));
			rightA.move(-(master.get_analog(ANALOG_LEFT_Y)));
			rightB.move(-(master.get_analog(ANALOG_LEFT_Y)));}

		if (master.get_digital_new_press(DIGITAL_A)) {
			autonomous();}

		if (master.get_digital_new_press(DIGITAL_L1)) {
			driveInvert = !driveInvert;
			lightDirec = !lightDirec;
			ledStrip1.cycle(*ledStrip1, 4, 0, lightDirec);
			ledStrip2.cycle(*ledStrip1, 4, 0, lightDirec);
			if (driveInvert) {driveCurrent = "IT";} else {driveCurrent = "FW";}}

		if (master.get_digital_new_press(DIGITAL_L2)){
			if (flySpinning) {fly.stop();}
			else {fly.set_velocity_custom_controller(3000);}
			flySpinning = !flySpinning;}

		if (master.get_digital_new_press(DIGITAL_RIGHT)){
			if (intakeSpinning) {intake.move_velocity(0);}
			else {intake.move_velocity(200);}
			intakeSpinning = !intakeSpinning;}
		if (master.get_digital_new_press(DIGITAL_DOWN)) {intakeSpinning = true; intake.move(-12);}
		
		if (master.get_digital_new_press(DIGITAL_Y)){
			if (rollerSpinning) {roller.move_velocity(0);}
			else {roller.move_velocity(100);}
			rollerSpinning = !rollerSpinning;}
		if (master.get_digital_new_press(DIGITAL_B)) {rollerSpinning = true; roller.move(-12);}
		
		if (master.get_digital_new_press(DIGITAL_LEFT)){
			if (brakeHold) {drive.set_brake_modes(MOTOR_BRAKE_COAST);}
			else {drive.set_brake_modes(MOTOR_BRAKE_HOLD);}
			brakeHold = !brakeHold;
			if (brakeHold) {brakeCurrent = "BR";} else {brakeCurrent = "NB";}}
		
        if (master.get_digital(DIGITAL_R2)) {disc1.set_value(true); delay(200);} else {disc1.set_value(false);}
        if (master.get_digital(DIGITAL_R1)) {disc3.set_value(true); delay(200);} else {disc3.set_value(false);}

		if (master.get_digital(DIGITAL_X)) {stringS.set_value(true); delay(200); stringS.set_value(false);}

		pros::delay(10);}}
