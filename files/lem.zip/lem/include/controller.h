#pragma once
#include "main.h"

extern okapi::Controller okapiController;
extern pros::Controller master;
extern void printer(void);
extern std::string printSpeed;