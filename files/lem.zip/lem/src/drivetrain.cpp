#include "autons.h"
#include "lemlib/chassis/chassis.hpp"
#include "lemlib/chassis/trackingWheel.hpp"
#include "main.h"
#include "okapi/impl/device/rotarysensor/adiEncoder.hpp"
#include "pros/adi.hpp"
#include "pros/misc.h"

int leftTarget; int rightTarget;
int leftPower; int rightPower;
int leftPrev; int rightPrev;

bool driveInvert = false;
bool brakeHold = false;
std::string driveCurrent = "FW";
std::string brakeCurrent = "NB";

Motor leftA(1, false);
Motor leftB(2, false);
Motor leftC(3, false);
Motor rightA(4, true);
Motor rightB(5, true);
Motor rightC(6, true);
MotorGroup leftDrive({leftA, leftB, leftC});
MotorGroup rightDrive({rightA, rightB, rightC});
MotorGroup drive({leftA, leftB, leftC, rightA, rightB, rightC});

ADIEncoder leftEnc('C', 'D', true);
ADIEncoder rightEnc('E', 'F', false);
ADIEncoder backEnc('G', 'H', false);

lemlib::TrackingWheel leftTrack(&leftEnc, 2.75, -5);
lemlib::TrackingWheel rightTrack(&rightEnc, 2.75, 5);
lemlib::TrackingWheel backTrack(&backEnc, 2.75, 7.08661);

lemlib::OdomSensors_t sensors {
	&leftTrack,
	&rightTrack,
	&backTrack,
	nullptr,
	nullptr
};

// forward/backward PID
lemlib::ChassisController_t lateralController {
    10, // kP
    30, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500 // largeErrorTimeout
};
// turning PID
lemlib::ChassisController_t angularController {
    2, // kP
    10, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500 // largeErrorTimeout
};
float trackWidth = 10.1575;

lemlib::Chassis chassis(&leftDrive, &rightDrive, trackWidth, lateralController, angularController, sensors);

void chassisControl (void) {
	
	if (master.get_digital_new_press(DIGITAL_A)) {experimentalAuton();}
	
	leftTarget = master.get_analog(ANALOG_LEFT_Y);
	rightTarget = master.get_analog(ANALOG_RIGHT_Y);
	leftPower = (15.8 * (tan(M_PI * leftTarget / 260)));
	rightPower = (15.8 * (tan(M_PI * rightTarget / 260)));
	
	leftA.move(leftPower);
	leftB.move(leftPower);
	leftC.move(leftPower);
	rightA.move(rightPower);
	rightB.move(rightPower);
	rightC.move(rightPower);
	
//	leftA.move((leftPower + leftPrev) / 2);
//	leftB.move((leftPower + leftPrev) / 2);
//	leftC.move((leftPower + leftPrev) / 2);
//	rightA.move((rightPower + rightPrev) / 2);
//	rightB.move((rightPower + rightPrev) / 2);
//	rightC.move((rightPower + rightPrev) / 2);	
	
	leftPrev = leftPower;
	rightPrev = rightPower;}