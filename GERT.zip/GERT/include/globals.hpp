#include "display/lv_core/lv_obj.h"
#include "main.h"
#include "pros/adi.hpp"
using namespace pros;

extern Motor leftA;
extern Motor leftB;
extern Motor rightA;
extern Motor rightB;
extern Motor intake;
extern Motor roller;
extern sylib::Motor flyA;
extern sylib::Motor flyB;
extern MotorGroup drive;
extern ADIDigitalOut string;
extern ADIDigitalOut indexer;
extern Optical optical;